Due to the fact that we don't have a full set of characters finished..
-sigh-

None of those are currently installed in the prototype. 
Instead, we have placeholders so that at least everything is seamlessly integrated and uniform.

However, if it counts (I know it counts as an original piece but unsure about this..):

In Art Pieces -> Exhibit A
It contains pictures that I have taken using my camera for the game.

tree.jpg -> Can be found in random scenes. The third scene for male will perhaps be easiest to find as the background.
olin.jpg -> First scene for female + male.
logo.png -> This however is actually finished, so it'll be the splashscreen of the game. 
		Can be found before menu screen on PC. After the renpy splashscreens on mobile.
goddardlab.jpg -> Where the students do labs. It'll appear a few times.

bg1.png+bg2.png+bg3.png+bg4.png+heart.png -> all put together to create an animation for the main menu. 
						Of course, you'll find it in the main menu.


Now as for characters we plan to implement (if the sets ever finish..) I have stored them in Exhibit B.

These three represent one pose of the three characters, which will be scattered throughout the game.